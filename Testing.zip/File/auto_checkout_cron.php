<?php
/**
 * Auto Checkout Cron Job
 * This script should be run daily at 10:00 AM via cron job
 * Add to crontab: 0 10 * * * /usr/bin/php /path/to/your/project/auto_checkout_cron.php
 */

require_once 'config/database.php';
require_once 'includes/functions.php';

// Set timezone
date_default_timezone_set('Asia/Kolkata'); // Adjust as per your timezone

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Get current date and time
    $current_date = date('Y-m-d');
    $current_time = date('Y-m-d H:i:s');
    
    // Find all checked-in rooms that need auto checkout
    $stmt = $pdo->prepare("
        SELECT b.*, r.room_number, r.room_name, u.username as admin_name 
        FROM bookings b 
        JOIN rooms r ON b.room_id = r.id 
        LEFT JOIN users u ON b.booked_by_admin = u.id 
        WHERE b.status = 'checked_in' 
        AND DATE(b.check_in_date) < ?
    ");
    $stmt->execute([$current_date]);
    $rooms_to_checkout = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $checkout_count = 0;
    
    foreach ($rooms_to_checkout as $booking) {
        // Update booking status to checked out
        $update_stmt = $pdo->prepare("
            UPDATE bookings 
            SET status = 'checked_out', 
                checkout_date = ?,
                auto_checkout = 1,
                updated_at = ?
            WHERE id = ?
        ");
        $update_stmt->execute([$current_time, $current_time, $booking['id']]);
        
        // Update room status to available
        $room_stmt = $pdo->prepare("UPDATE rooms SET status = 'available' WHERE id = ?");
        $room_stmt->execute([$booking['room_id']]);
        
        // Log admin activity
        $activity_stmt = $pdo->prepare("
            INSERT INTO admin_activities 
            (admin_id, activity_type, description, booking_id, room_id, created_at) 
            VALUES (?, 'auto_checkout', ?, ?, ?, ?)
        ");
        
        $description = "Auto checkout - Room {$booking['room_number']} ({$booking['room_name']}) - Guest: {$booking['guest_name']}";
        $activity_stmt->execute([
            $booking['booked_by_admin'], 
            $description, 
            $booking['id'], 
            $booking['room_id'], 
            $current_time
        ]);
        
        $checkout_count++;
    }
    
    // Log the cron job execution
    $log_stmt = $pdo->prepare("
        INSERT INTO system_logs (log_type, message, created_at) 
        VALUES ('auto_checkout', ?, ?)
    ");
    $log_message = "Auto checkout completed. {$checkout_count} rooms processed.";
    $log_stmt->execute([$log_message, $current_time]);
    
    echo "Auto checkout completed successfully. {$checkout_count} rooms checked out.\n";
    
} catch (PDOException $e) {
    $error_message = "Auto checkout failed: " . $e->getMessage();
    echo $error_message . "\n";
    
    // Log error
    try {
        $error_stmt = $pdo->prepare("
            INSERT INTO system_logs (log_type, message, created_at) 
            VALUES ('error', ?, ?)
        ");
        $error_stmt->execute([$error_message, date('Y-m-d H:i:s')]);
    } catch (Exception $log_error) {
        // If logging fails, at least output to console
        echo "Failed to log error: " . $log_error->getMessage() . "\n";
    }
}
?>