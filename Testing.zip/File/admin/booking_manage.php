<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

$pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Handle booking actions
if ($_POST) {
    if (isset($_POST['action'])) {
        $booking_id = $_POST['booking_id'];
        $action = $_POST['action'];
        
        try {
            switch ($action) {
                case 'check_in':
                    $stmt = $pdo->prepare("
                        UPDATE bookings 
                        SET status = 'checked_in', 
                            check_in_date = NOW(),
                            booked_by_admin = ?
                        WHERE id = ?
                    ");
                    $stmt->execute([$_SESSION['user_id'], $booking_id]);
                    
                    // Update room status
                    $room_stmt = $pdo->prepare("
                        UPDATE rooms r 
                        JOIN bookings b ON r.id = b.room_id 
                        SET r.status = 'occupied' 
                        WHERE b.id = ?
                    ");
                    $room_stmt->execute([$booking_id]);
                    
                    // Log activity
                    logAdminActivity($pdo, $_SESSION['user_id'], 'check_in', "Manual check-in for booking ID: $booking_id", $booking_id);
                    
                    $success_message = "Guest checked in successfully!";
                    break;
                    
                case 'check_out':
                    $stmt = $pdo->prepare("
                        UPDATE bookings 
                        SET status = 'checked_out', 
                            checkout_date = NOW(),
                            auto_checkout = 0
                        WHERE id = ?
                    ");
                    $stmt->execute([$booking_id]);
                    
                    // Update room status
                    $room_stmt = $pdo->prepare("
                        UPDATE rooms r 
                        JOIN bookings b ON r.id = b.room_id 
                        SET r.status = 'available' 
                        WHERE b.id = ?
                    ");
                    $room_stmt->execute([$booking_id]);
                    
                    // Log activity
                    logAdminActivity($pdo, $_SESSION['user_id'], 'check_out', "Manual check-out for booking ID: $booking_id", $booking_id);
                    
                    $success_message = "Guest checked out successfully!";
                    break;
                    
                case 'cancel':
                    $stmt = $pdo->prepare("UPDATE bookings SET status = 'cancelled' WHERE id = ?");
                    $stmt->execute([$booking_id]);
                    
                    // Update room status
                    $room_stmt = $pdo->prepare("
                        UPDATE rooms r 
                        JOIN bookings b ON r.id = b.room_id 
                        SET r.status = 'available' 
                        WHERE b.id = ?
                    ");
                    $room_stmt->execute([$booking_id]);
                    
                    // Log activity
                    logAdminActivity($pdo, $_SESSION['user_id'], 'cancel', "Cancelled booking ID: $booking_id", $booking_id);
                    
                    $success_message = "Booking cancelled successfully!";
                    break;
            }
        } catch (PDOException $e) {
            $error_message = "Error: " . $e->getMessage();
        }
    }
}

// Fetch all bookings with room and admin details
$stmt = $pdo->prepare("
    SELECT 
        b.*,
        r.room_number,
        r.room_name,
        r.room_type,
        u.username as admin_name,
        CASE 
            WHEN b.auto_checkout = 1 THEN 'Auto'
            ELSE 'Manual'
        END as checkout_type
    FROM bookings b
    JOIN rooms r ON b.room_id = r.id
    LEFT JOIN users u ON b.booked_by_admin = u.id
    ORDER BY b.created_at DESC
");
$stmt->execute();
$bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Function to log admin activities
function logAdminActivity($pdo, $admin_id, $activity_type, $description, $booking_id = null, $room_id = null) {
    $stmt = $pdo->prepare("
        INSERT INTO admin_activities 
        (admin_id, activity_type, description, booking_id, room_id, created_at) 
        VALUES (?, ?, ?, ?, ?, NOW())
    ");
    $stmt->execute([$admin_id, $activity_type, $description, $booking_id, $room_id]);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Management - Hotel Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .auto-checkout-badge {
            background-color: #17a2b8;
            color: white;
            font-size: 0.75rem;
            padding: 2px 6px;
            border-radius: 10px;
        }
        .manual-checkout-badge {
            background-color: #28a745;
            color: white;
            font-size: 0.75rem;
            padding: 2px 6px;
            border-radius: 10px;
        }
        .room-info {
            font-weight: bold;
            color: #495057;
        }
        .status-badge {
            font-size: 0.8rem;
            padding: 4px 8px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-2 d-md-block bg-light sidebar">
                <div class="position-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="dashboard.php">
                                <i class="fas fa-tachometer-alt"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="booking_manage.php">
                                <i class="fas fa-calendar-check"></i> Manage Bookings
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="admin_activity.php">
                                <i class="fas fa-history"></i> Admin Activity
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="rooms.php">
                                <i class="fas fa-bed"></i> Manage Rooms
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Main content -->
            <main class="col-md-10 ms-sm-auto px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Booking Management</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <div class="btn-group me-2">
                            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="location.reload()">
                                <i class="fas fa-sync-alt"></i> Refresh
                            </button>
                        </div>
                    </div>
                </div>

                <?php if (isset($success_message)): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo $success_message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if (isset($error_message)): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo $error_message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- Auto Checkout Info -->
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i>
                    <strong>Auto Checkout:</strong> All checked-in rooms are automatically checked out daily at 10:00 AM. 
                    Auto checkout activities are tracked and visible in the Admin Activity section.
                </div>

                <!-- Bookings Table -->
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th>Booking ID</th>
                                <th>Room Details</th>
                                <th>Guest Information</th>
                                <th>Dates</th>
                                <th>Status</th>
                                <th>Booked By Admin</th>
                                <th>Checkout Type</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($bookings as $booking): ?>
                                <tr>
                                    <td>
                                        <strong>#<?php echo $booking['id']; ?></strong>
                                    </td>
                                    <td>
                                        <div class="room-info">
                                            Room <?php echo htmlspecialchars($booking['room_number']); ?>
                                        </div>
                                        <small class="text-muted">
                                            <?php echo htmlspecialchars($booking['room_name']); ?>
                                            <br>
                                            <em><?php echo htmlspecialchars($booking['room_type']); ?></em>
                                        </small>
                                    </td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($booking['guest_name']); ?></strong>
                                        <br>
                                        <small class="text-muted">
                                            <i class="fas fa-envelope"></i> <?php echo htmlspecialchars($booking['guest_email']); ?>
                                            <br>
                                            <i class="fas fa-phone"></i> <?php echo htmlspecialchars($booking['guest_phone']); ?>
                                        </small>
                                    </td>
                                    <td>
                                        <small>
                                            <strong>Check-in:</strong><br>
                                            <?php echo date('M d, Y', strtotime($booking['check_in_date'])); ?>
                                            <br>
                                            <strong>Check-out:</strong><br>
                                            <?php echo date('M d, Y', strtotime($booking['check_out_date'])); ?>
                                            <?php if ($booking['checkout_date']): ?>
                                                <br>
                                                <strong>Actual:</strong><br>
                                                <?php echo date('M d, Y H:i', strtotime($booking['checkout_date'])); ?>
                                            <?php endif; ?>
                                        </small>
                                    </td>
                                    <td>
                                        <?php
                                        $status_class = '';
                                        switch ($booking['status']) {
                                            case 'confirmed':
                                                $status_class = 'bg-warning text-dark';
                                                break;
                                            case 'checked_in':
                                                $status_class = 'bg-success';
                                                break;
                                            case 'checked_out':
                                                $status_class = 'bg-secondary';
                                                break;
                                            case 'cancelled':
                                                $status_class = 'bg-danger';
                                                break;
                                            default:
                                                $status_class = 'bg-light text-dark';
                                        }
                                        ?>
                                        <span class="badge <?php echo $status_class; ?> status-badge">
                                            <?php echo ucfirst($booking['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($booking['admin_name']): ?>
                                            <i class="fas fa-user-shield"></i>
                                            <?php echo htmlspecialchars($booking['admin_name']); ?>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($booking['status'] === 'checked_out'): ?>
                                            <?php if ($booking['auto_checkout']): ?>
                                                <span class="auto-checkout-badge">
                                                    <i class="fas fa-clock"></i> Auto
                                                </span>
                                            <?php else: ?>
                                                <span class="manual-checkout-badge">
                                                    <i class="fas fa-user"></i> Manual
                                                </span>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($booking['status'] === 'confirmed'): ?>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="booking_id" value="<?php echo $booking['id']; ?>">
                                                <input type="hidden" name="action" value="check_in">
                                                <button type="submit" class="btn btn-sm btn-success" 
                                                        onclick="return confirm('Check in this guest?')">
                                                    <i class="fas fa-sign-in-alt"></i> Check In
                                                </button>
                                            </form>
                                        <?php elseif ($booking['status'] === 'checked_in'): ?>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="booking_id" value="<?php echo $booking['id']; ?>">
                                                <input type="hidden" name="action" value="check_out">
                                                <button type="submit" class="btn btn-sm btn-warning" 
                                                        onclick="return confirm('Check out this guest?')">
                                                    <i class="fas fa-sign-out-alt"></i> Check Out
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                        
                                        <?php if (in_array($booking['status'], ['confirmed', 'checked_in'])): ?>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="booking_id" value="<?php echo $booking['id']; ?>">
                                                <input type="hidden" name="action" value="cancel">
                                                <button type="submit" class="btn btn-sm btn-danger" 
                                                        onclick="return confirm('Cancel this booking?')">
                                                    <i class="fas fa-times"></i> Cancel
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <?php if (empty($bookings)): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>
                        <h5 class="text-muted">No bookings found</h5>
                        <p class="text-muted">Bookings will appear here once guests make reservations.</p>
                    </div>
                <?php endif; ?>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>