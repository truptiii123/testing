<?php
/**
 * Auto Checkout Cron Job - Fixed Version
 * This script should be run daily at 10:00 AM via cron job
 * Add to crontab: 0 10 * * * /usr/bin/php /path/to/your/project/auto_checkout_cron_fixed.php
 */

// Include your database configuration
require_once 'config/database.php';

// Set timezone (adjust as per your location)
date_default_timezone_set('Asia/Kolkata');

try {
    // Create PDO connection
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Get current date and time
    $current_date = date('Y-m-d');
    $current_time = date('Y-m-d H:i:s');
    
    echo "Starting auto checkout process at: $current_time\n";
    
    // Find all checked-in rooms that need auto checkout
    // Looking for rooms checked in before today that are still checked in
    $stmt = $pdo->prepare("
        SELECT b.*, r.room_number, r.room_name, u.username as admin_name 
        FROM bookings b 
        JOIN rooms r ON b.room_id = r.id 
        LEFT JOIN users u ON b.booked_by_admin = u.id 
        WHERE b.status = 'checked_in' 
        AND DATE(b.check_in_date) < ?
    ");
    $stmt->execute([$current_date]);
    $rooms_to_checkout = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $checkout_count = 0;
    
    echo "Found " . count($rooms_to_checkout) . " rooms to checkout\n";
    
    foreach ($rooms_to_checkout as $booking) {
        echo "Processing Room {$booking['room_number']} - Guest: {$booking['guest_name']}\n";
        
        // Update booking status to checked out
        $update_stmt = $pdo->prepare("
            UPDATE bookings 
            SET status = 'checked_out', 
                checkout_date = ?,
                auto_checkout = 1,
                updated_at = ?
            WHERE id = ?
        ");
        $update_stmt->execute([$current_time, $current_time, $booking['id']]);
        
        // Update room status to available
        $room_stmt = $pdo->prepare("UPDATE rooms SET status = 'available' WHERE id = ?");
        $room_stmt->execute([$booking['room_id']]);
        
        // Log admin activity
        $activity_stmt = $pdo->prepare("
            INSERT INTO admin_activities 
            (admin_id, activity_type, description, booking_id, room_id, created_at) 
            VALUES (?, 'auto_checkout', ?, ?, ?, ?)
        ");
        
        $description = "Auto checkout - Room {$booking['room_number']}";
        if ($booking['room_name']) {
            $description .= " ({$booking['room_name']})";
        }
        $description .= " - Guest: {$booking['guest_name']}";
        
        $admin_id = $booking['booked_by_admin'] ? $booking['booked_by_admin'] : 1; // Default to admin ID 1 if null
        
        $activity_stmt->execute([
            $admin_id, 
            $description, 
            $booking['id'], 
            $booking['room_id'], 
            $current_time
        ]);
        
        $checkout_count++;
        echo "Checked out Room {$booking['room_number']} successfully\n";
    }
    
    // Log the cron job execution
    $log_stmt = $pdo->prepare("
        INSERT INTO system_logs (log_type, message, created_at) 
        VALUES ('auto_checkout', ?, ?)
    ");
    $log_message = "Auto checkout completed successfully. {$checkout_count} rooms processed.";
    $log_stmt->execute([$log_message, $current_time]);
    
    echo "Auto checkout completed successfully. {$checkout_count} rooms checked out.\n";
    echo "Process finished at: " . date('Y-m-d H:i:s') . "\n";
    
} catch (PDOException $e) {
    $error_message = "Auto checkout failed: " . $e->getMessage();
    echo $error_message . "\n";
    
    // Try to log error if possible
    try {
        if (isset($pdo)) {
            $error_stmt = $pdo->prepare("
                INSERT INTO system_logs (log_type, message, created_at) 
                VALUES ('error', ?, ?)
            ");
            $error_stmt->execute([$error_message, date('Y-m-d H:i:s')]);
        }
    } catch (Exception $log_error) {
        echo "Failed to log error: " . $log_error->getMessage() . "\n";
    }
} catch (Exception $e) {
    echo "General error: " . $e->getMessage() . "\n";
}
?>